## Поддержка Arduino ESP32 Core 2.0.17

В интерфейсе добавлен выбор Core 2.0.17 / 3.3.11 (по умолчанию 2.0.17). Выбранная версия применяется к статической проверке ESP32 и сохраняется в `.i2u.json`; при загрузке проекта восстанавливается. Проверки API версий независимы. Это не означает подтверждённую компиляцию в FLProg или на плате с Core 2.0.17. Встроенная инструкция для ИИ (INO2UBI_AI_GUIDE_v9.txt, раздел 6А) описывает Core 2.0.17 со стандартными библиотеками. Проверка 2.0.17 отклоняет API ядра 3.x: ledcAttach*, новый timerBegin/timerAlarm, esp_task_wdt_config_t, Network*, esp_now_*_info_t и др. Тест: tests/esp32-core2017-regression.js.

# INO2UBI v2.16 RC2 — AUDIT FIX (проверяемый кандидат)

Основа: RC2 Code Professional / FLProg 9.8.6 / ESP32 Arduino Core 3.3.11.

Включены защитные исправления P0 и части замечаний HIGH/MEDIUM аудита: контроль глобальных указателей, ссылок, 64-битных типов, массивов, static, объявлений типов, объектов без конструктора; обнаружение некоторых потерянных аннотированных объявлений и зависимостей от порядка, поддержка setup(void)/loop(void), защита от некорректной подстановки членов объектов, дополнительная обработка callback, изоляция локальных переменных внутри блоков setup/loop, исправление подсказок Core 3.3.11.

Неподдерживаемые конструкции блокируются диагностикой вместо молчаливой порчи, что **сужает** область экспортируемого C++ относительно RC2. Полноценная поддержка произвольного C++ не заявлена. Некоторые сложные конструкции парсера могут оставаться непроверенными.

Проверено: синтаксис JS, тесты парсера и диагностики; GitHub Pages и полный экспорт в браузере не подтверждены; импорт/компиляция в FLProg 9.8.6 и испытания на ESP32 не выполнялись. Не заменять стабильную RC2 до подтверждения в целевой среде.


## Callback UUID fix (candidate)
- Helper function identifiers used as callback arguments or function-pointer values are UUID-tagged, not only direct calls.
- Namespace and member accesses remain unchanged.
- Validate with two FLProg instances under ESP32 Core 3.3.11.

## H2 String constructor UUID fix (candidate)
A global `String name("value");` is registered as per-instance C++ object, so the declaration and member accesses are UUID-tagged. The original Arduino API, include and object state remain unchanged. A real two-instance FLProg compilation is still required.


H3 candidate: original relative order of parsed global variables, statics and constructor declarations is retained in Professional declare code via declaration_order. Existing callback/H2 fixes retained. Reparse old .i2u.json projects with mixed declarations. Nested String constructors with ambiguous parsing are rejected. Browser export / FLProg 9.8.6 compilation must be confirmed by user.


## RC2 AUDIT FINAL CANDIDATE — 14.11.2026

- Сохранены исправления H1 (передача callback), H2 (UUID объектов String), H3 (порядок глобальных объявлений).
- C4: однострочные функциональные #define сохраняются как исходная директива; предупреждение уточнено, многострочные директивы блокируются.
- H5: сохранена защита обращений к членам объектов/namespace от ошибочной UUID-подстановки.
- Диагностика отличает числовые массивы от массивов объектов и указывает строки для проверенных случаев H4/H6/C2/C5/M5.
- Статус: кандидат. FLProg-компиляция именно этого ZIP и работа на ESP32 требуют подтверждения.


## FIXED A-01…A-13 (НЕ ИСПЫТАНО, не STABLE) — 14.11.2026

Исправления по `AUDIT_REPORT.md`. После правок тесты, браузерные прогоны и компиляция в FLProg 9.8.6 / на ESP32 **не выполнялись**. Версию нельзя считать стабильной.

- A-01: для всех хелперов в declare генерируются прототипы (значения параметров по умолчанию остаются только в прототипе).
- A-02: UUID получают объекты `Type n(args)`, `Type n{args}`, `Type n = expr` и все имена в списках `Type a(1), b(2);`; список безаргументных объектов (`Servo s1, s2;`) блокируется.
- A-03: массив внутри списка деклараторов (`int a=1, c[3];`) блокируется как глобальный массив.
- A-04/A-05: `#define`/`#include` после начала setup()/loop(), `#undef`, `#pragma` (кроме `once`), `#error`, `#warning`, `#line` и `#if/#ifdef/#else/#endif` вне функций блокируются с номером строки; внутри функций условные директивы сохраняются как есть.
- A-06: для Core 3.3.11 добавлены: проверка сигнатуры приёмного callback ESP-NOW (`const esp_now_recv_info_t*`), предупреждение о сигнатуре callback отправки, предупреждения об отсутствии `<WiFi.h>`/`<esp_now.h>`, `esp_task_wdt_init`, ошибка `hallRead`; подсказки Core 2.x удалены.
- A-07: строки для static, объектов без аргументов, массивов объектов (теперь указывает на объект) и `ledcWrite`.
- A-08: при открытии `.i2u.json` списки extra/static объявлений берутся из актуального разбора кода.
- A-09: ограничение на глобальные указатели сохранено, сообщение объясняет причину; предупреждение ESP8266 уточнено.
- A-10: исправлено смещение строки `while()` при CRLF.
- A-11: кириллица в имени блока транслитерируется в имени файла `.ubi`.
- A-12: внутренние ID блока выбираются через `crypto.getRandomValues` (диапазон и формат прежние).
- A-13: удалены неиспользуемые `crc32`/`zipFiles`; обновлены версия и комментарий в `esp32.js`.

### Разрешение нескольких экземпляров (Code Professional)

В настройках блока установлен флажок «Использовать блок несколько раз в одном проекте FLProg» (по умолчанию ВЫКЛЮЧЕН).
В экспортируемом `.ubi` это поле `isUseItOnce`: `False` при включённой галочке (разрешены повторные экземпляры) и `True` при выключенной (один экземпляр).
Выбор сохраняется в `.i2u.json` как `settings.allowMultipleInstances` и восстанавливается при открытии проекта; отсутствующее поле в старом проекте означает включённую галочку.
Диагностика запускается повторно при переключении режима и перед экспортом. Проверки изоляции состояния, например запрет глобальных `static` и массивов при нескольких экземплярах, применяются в многократном режиме. Прочие ограничения парсера и общих ресурсов остаются для обоих режимов.
Проверка в браузере не заменяет импорт в FLProg и фактическую компиляцию проекта с несколькими экземплярами.

Тест: `python tests/instance-mode-browser.py` (требуются Playwright и Chromium).


## RC3 — аудит режимов «несколько экземпляров» и «En» (15.11.2026) — НЕ ПРОВЕРЕНО В FLPROG

Исправлено (первопричины, а не симптомы):
- `diagnostics.js`: функция `forDisplay()` была описана в `DIAGNOSTICS_DISPLAY_CHANGELOG.md` и использовалась тестом, но в коде отсутствовала. Реализована; `app.js` теперь показывает отфильтрованный список, а счётчики в заголовке равны числу показанных карточек. Добавлено общее правило привязки к строке для сообщений вида `[ID] (строка N)`.
- `compat.js` / `index.html`: модули `conversion-safety.js` и `runtime-safety.js` не загружались в браузере и не вызывались валидатором — их проверки (NAME-COLLISION, INIT-LOOP, CALLBACK-SCOPE, XML-CHAR, BLOCKING-IO, TIMER-* …) молча не работали. Подключены. Проверки, сознательно смягчённые для Code Professional (функциональные макросы C4, аргументы по умолчанию A-01, порядок объявлений H3), как ошибки не включаются.
- `#ifdef` вне функций: сообщение получило идентификатор `[CPP-CONDITION]` и строку; внутри функций директивы по-прежнему сохраняются как есть (предупреждение).
- `volatile`/`const`: квалификатор после типа (`int volatile x`, `unsigned long const N`) молча терялся парсером; теперь переносится в объявление. Тест, ожидавший отказ для `volatile bool flag`, был устаревшим: такие переменные поддерживаются, квалификатор сохраняется в C++ (проверяется).
- Парсер молча отбрасывал `std::array<int, 3> arr;` (запятая внутри `<>`); исправлено.
- Режим «один экземпляр» (`isUseItOnce = True`): проверки независимости экземпляров (глобальные `static`, массивы, шаблонные и безаргументные объекты, `constexpr`) не выдаются; предупреждения о ресурсах `[MULTI-RESOURCE]` — только в многократном режиме. Ограничения, не связанные с числом экземпляров (указатели, enum/struct/class), действуют в обоих режимах.
- Режим «несколько экземпляров»: новая диагностика `[MULTI-RESOURCE]` (ESP-NOW, BLE, Wi-Fi, Wire/SPI, Serial, EEPROM, таймеры/LEDC) и ошибка для `constexpr/inline/thread_local` (не получают UUID → повторное определение).
- Вход `En`: добавлена проверка занятости имени (переменная, параметр, `#define`, функция, объект, псевдоним контакта); переключение галочки сразу перезапускает диагностику.
- Настройки: `compat.restoreSettings()` — единое место восстановления из `.i2u.json` (нет поля → выключено).
- Параметры: значения по умолчанию проверяются в диагностике (с номером строки), а не только при экспорте; `char X = 'A'; // par` теперь принимается (код символа).
- Code Basic (не входит в интерфейс): `unsigned long`/`uint32_t` отображались в знаковый `LongDataType`; в `createUbiXmlSixx` не вызывалась изоляция экземпляров `basic-instance.js`.

Тесты: `node tests/run-all.js` (однократно `npm install` в `tests/tools`: jsdom, web-tree-sitter, tree-sitter-wasms).
Новые: `tests/instance-mode-regression.js` (4 сочетания галочек через реальный `index.html`+`app.js`, разбор `.ubi`, грамматика C++, сохранение/восстановление), `tests/examples-regression.js`; вспомогательные `tests/lib/*`.
Проверка C++ — синтаксическая (tree-sitter-cpp); компилятора C++ и FLProg на машине проверки не было: типы, библиотеки и импорт `.ubi` в FLProg 9.8.x не проверялись.
Браузерные тесты на Playwright (`tests/*.py`) здесь не запускались (нет Playwright/Chromium). `tests/ble-regression.js` относится к BLE Core 2.0.17 (вне Code Professional) и остаётся в списке как LEGACY-FAIL.

## RC4 — глобальные массивы, галочка по умолчанию (НЕ ПРОВЕРЕНО В FLPROG)

- Галочка «Использовать блок несколько раз в одном проекте» по умолчанию **снята** (новый проект, «Очистить», старый проект без сохранённого параметра). Сохранённое значение восстанавливается как есть. Снята → `isUseItOnce = True`, установлена → `False`.
- Глобальные массивы встроенных типов (`int`, `float`, `bool`, `byte`, `char`, `String`, `uintN_t`…), в том числе `int values[10] = {0};`, `float t[5];`, `bool s[8];`, `int a = 1, c[3];`, `const int tbl[3] = {…}`, изолируются по экземплярам: имя получает UUID-суффикс экземпляра и в объявлении, и во всех обращениях (setup, loop, вспомогательные функции, инициализаторы). Тип, размер и начальные значения сохраняются.
- Остаются диагностическими ограничениями: массивы объектов (`Servo s[2];`), `static`-массивы при нескольких экземплярах, размер не литералом (`[]`, `[N]`), массивы указателей, 64-битные типы, конфликт имени массива с переменной/`#define`/функцией/повторным объявлением.
- Браузерные Python-тесты больше не зависят от точного форматирования тегов `<script>` в `index.html`.
- Новый тест: `node tests/global-arrays-regression.js` (два экземпляра в одной единице трансляции, проверка грамматики C++).
- Импорт в FLProg и компиляция реального проекта с несколькими экземплярами НЕ выполнялись.

### RC4 local-variable UUID fix (FLProg 9.8.6)

When "Использовать блок несколько раз" is enabled, simple automatic scalar declarations in `setup()` and `loop()` (e.g. `uint32_t curTm = millis();`) now receive a native per-instance FLProg UUID suffix in both declarations and references. This avoids duplicate local declarations if FLProg concatenates code fragments into one function scope. With the checkbox off the original identifiers remain unchanged. Global UUID handling and En behavior are unchanged.

This is intentionally a conservative transformation: complex C++ local declarations (structured bindings, custom classes, pointer/reference declarations, compound declarator lists) are not yet automatically isolated; verify generated FLProg C++ for these cases. A browser/g++ regression is included in `tests/local-uuid-browser.py`.


## RC4 hardening: многократные экземпляры (16.11.2026)

- В Code Professional при включённой опции нескольких экземпляров простые глобальные `static`-скаляры и `static`-массивы примитивных типов получают стандартный тег UUID FLProg; исходный квалификатор `static` сохраняется.
- Простые локальные `static`-скаляры в `setup()`/`loop()` также получают UUID и сохраняют свою семантику времени жизни. В однократном режиме поведение не меняется.
- Диагностика `[MULTI-RESOURCE]` расширена на `attachInterrupt`, GPIO ISR ESP-IDF, `esp_timer_*`, `xTaskCreate*`; она предупреждает о реальных общих аппаратных и RTOS-ресурсах, но НЕ доказывает корректность разделения ресурса.
- Глобальные указатели, пользовательские классы, сложные статические объекты и другие конструкции без доказанной безопасной изоляции по-прежнему ограничены; нельзя обещать поддержку произвольного C++.
- Добавлен `tests/hardening-browser.py`: 15 проверок реальной генерации `.ubi` в Chromium, отрицательные случаи, два экземпляра и синтаксическая компиляция через `g++` для поддерживаемых новых статических объявлений. **Это не проверка импорта FLProg/ESP32.**

## Эксперимент: список выбора в свойствах готового блока FLProg

Для числового параметра Code Professional можно указать варианты в комментарии объявления:

```cpp
uint8_t Mode = 1; // par: Mode | choices: 0=Выключено; 1=Автоматически; 2=Вручную
```

Пары разделяются `;`, слева — значение, справа — подпись у радиокнопки. Требуются минимум два варианта; значение по умолчанию должно совпадать с одним из них. Без `| choices:` сохраняется обычный редактор параметра. Значения проверяются на допустимый диапазон типа; повторяющиеся значения отвергаются. Варианты сериализуются как `UserCodeMultiBlockRadioButtonParametrSpecies` с коллекциями `choices` и `booleanChoices`, по образцу файла FLProg «04.Изменение числовых форматов (Code - Professional).ubi». **Реальное отображение в FLProg 9.8.6 ещё нужно проверить импортом тестового блока**: XML-проверка не заменяет открытие окна свойств.

Уточнение по официальным исходникам ESP32 Core 2.0.17: analogWrite(pin,value), analogWriteFrequency(freq), analogWriteResolution(bits), ledcChangeFrequency(channel,freq,bits) и SET_LOOP_TASK_STACK_SIZE поддерживаются. Ложные запреты удалены.


## Внешние Wi-Fi-блоки FLProg (инструкция v10)

Для проектов с ESP32 Core 2.0.17 (по умолчанию) и 3.3.11 подключение, настройку и переподключение Wi-Fi выполняют отдельные блоки схемы FLProg. Пользовательские блоки INO2UBI Code Professional (.ubi) не должны повторно вызывать `WiFi.begin()`, `WiFi.mode()` или создавать собственный сетевой стек без явно согласованной архитектуры. Стандартные заголовки ядра и внешние блоки схемы FLProg — разные понятия. Полные правила — в `INO2UBI_AI_GUIDE_v10.txt`, разделы 6А.3 и 6Б.
