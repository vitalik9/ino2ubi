/* FIX23: Preserve integral parameter types when FLProg strips C++ literal suffixes.
 * FIX17: Snapshot parameter expressions to preserve numeric and String usage.
 * FIX14: A // par String is emitted by FLProg as a C++ string literal, not an
 * Arduino String object. Keep the source's String semantics in both formats.
 * This is a source-to-source transform for code SECTIONS, not macro expansion.
 */
(function (root) {
  'use strict';
  function collect(variables, defines) {
    const names = new Set();
    for (const [name, info] of Object.entries(variables || {})) {
      if (info && info.role === 'parameter' && info.type === 'String' && /^[A-Za-z_]\w*$/.test(name)) names.add(name);
    }
    for (const def of defines || []) {
      if (def && def.role === 'parameter' && def.type === 'String' && /^[A-Za-z_]\w*$/.test(def.name || '')) names.add(def.name);
    }
    return [...names];
  }
  function collectNumeric(variables, defines) {
    const names = [];
    const types = new Map();
    const add = (name, info) => {
      if (!info || info.role !== 'parameter' || info.type === 'String' || !/^[A-Za-z_]\w*$/.test(name)) return;
      if (!/^(?:bool|boolean|byte|uint8_t|int|int16_t|uint16_t|long|unsigned long|int32_t|uint32_t|float|double|char)$/.test(info.type)) return;
      if (!names.includes(name)) names.push(name);
      // FIX31: Snapshot every supported numeric/boolean parameter with its
      // declared C++ type, not `auto` (which promotes floating literals to
      // double and boolean tags to int). This also preserves FIX23 unsigned
      // integer behavior when FLProg strips U/L literal suffixes.
      // FLProg expands input fields as C++ expressions; explicit initialization
      // performs the intended conversion for both literal and connected values.
      const cppType = String(info.type || '');
      const snapshotType = cppType === 'boolean' ? 'bool' : cppType;
      types.set(name, snapshotType);
    };
    for (const [name, info] of Object.entries(variables || {})) add(name, info);
    for (const d of defines || []) if (d) add(d.name, d);
    names.types = types;
    return names;
  }
  function transform(source, parameterNames, excludedNames, numericNames) {
    const text = String(source || '');
    const strings = new Set(parameterNames || []);
    const numerics = new Set(numericNames || []);
    const numericTypes = numericNames && numericNames.types instanceof Map ? numericNames.types : new Map();
    const selected = new Set([...strings, ...numerics]);
    for (const name of excludedNames || []) selected.delete(name);
    if (!text.trim() || selected.size === 0) return text;
    // maskNonCode is defined by parser.js; it blanks comments, strings and
    // character literals without changing offsets or newlines.
    if (typeof maskNonCode !== 'function') throw new Error('Не загружен C++-парсер для строковых параметров.');
    const masked = maskNonCode(text);
    const aliases = new Map();
    const replacements = [];
    const token = /[A-Za-z_]\w*/g;
    let match;
    while ((match = token.exec(masked))) {
      const name = match[0];
      if (!selected.has(name)) continue;
      const pos = match.index;
      // Do not touch preprocessor directives or an object's/namespace's field.
      const lineStart = masked.lastIndexOf('\n', pos - 1) + 1;
      if (/^\s*#/.test(masked.slice(lineStart, pos))) continue;
      const before = masked.slice(0, pos).trimEnd();
      if (before.endsWith('.') || before.endsWith('->') || before.endsWith('::')) continue;
      if (!aliases.has(name)) {
        const stem = (strings.has(name) ? '__ino2ubi_string_' : '__ino2ubi_numeric_') + name;
        let alias = stem, i = 2;
        while (new RegExp('\\b' + alias + '\\b').test(text) || [...aliases.values()].includes(alias)) alias = stem + '_' + i++;
        aliases.set(name, alias);
      }
      replacements.push({start:pos, end:pos + name.length, alias:aliases.get(name)});
    }
    if (!replacements.length) return text;
    let rendered = '', cursor = 0;
    for (const r of replacements) {
      rendered += text.slice(cursor, r.start) + r.alias;
      cursor = r.end;
    }
    rendered += text.slice(cursor);
    // A C++ String value is required here, rather than a raw FLProg parameter
    // expression (which can expand to e.g. "pool.ntp.org"). One snapshot per
    // execution is intentional: updated parameter values are read every loop.
    // The scoped block also prevents collisions when a block is used twice.
    const declarations = [...aliases].map(([name, alias]) =>
      '  ' + (strings.has(name) ? 'String ' : (numericTypes.get(name) ? numericTypes.get(name) + ' ' : 'auto ')) + alias + ' = ' + name + ';'
    ).join('\n');
    return '{\n' + declarations + '\n' + rendered + '\n}';
  }
  root.ino2ubiStringParams = {collect, collectNumeric, transform};
})(typeof window !== 'undefined' ? window : globalThis);
